import urllib.request as req
from bs4 import BeautifulSoup

url = "http://www.kma.go.kr/weather/forecast/mid-term-rss3.jsp"
res = req.urlopen(url)

soup = BeautifulSoup(res, 'html.parser')

title = soup.find('item').title.string
wf = soup.find('item').wf.string

print("title = " + title)
print("wf = " + wf)


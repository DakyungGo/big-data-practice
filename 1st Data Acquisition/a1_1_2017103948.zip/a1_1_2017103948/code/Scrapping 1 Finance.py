import urllib.request as req
from bs4 import BeautifulSoup

url = "https://finance.naver.com/marketindex/"
res = req.urlopen(url)

soup = BeautifulSoup(res, 'html.parser')

price = soup.select_one('#exchangeList > li.on > a.head.usd > div > span.value').string

print("price = " + price)

